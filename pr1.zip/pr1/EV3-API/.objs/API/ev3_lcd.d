.objs/API/ev3_lcd.o: API/ev3_lcd.c API/normal_font.xbm API/small_font.xbm \
  API/large_font.xbm API/tiny_font.xbm API/normal_icons.xbm \
  API/small_icons.xbm API/large_icons.xbm API/menu_icons.xbm \
  API/arrow_icons.xbm
API/normal_font.xbm:
API/small_font.xbm:
API/large_font.xbm:
API/tiny_font.xbm:
API/normal_icons.xbm:
API/small_icons.xbm:
API/large_icons.xbm:
API/menu_icons.xbm:
API/arrow_icons.xbm:
