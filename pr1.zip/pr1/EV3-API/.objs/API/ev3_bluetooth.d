.objs/API/ev3_bluetooth.o: API/ev3_bluetooth.c
