.objs/API/sensors/ht_ir_v2.o: API/sensors/ht_ir_v2.c \
  API/inputs/ev3_input_iic.h API/sensors/ev3_sensors.h
API/inputs/ev3_input_iic.h:
API/sensors/ev3_sensors.h:
