.objs/API/sensors/utility.o: API/sensors/utility.c \
  API/sensors/../inputs/ev3_input_uart.h API/sensors/utility.h \
  API/sensors/ev3_sensors.h
API/sensors/../inputs/ev3_input_uart.h:
API/sensors/utility.h:
API/sensors/ev3_sensors.h:
