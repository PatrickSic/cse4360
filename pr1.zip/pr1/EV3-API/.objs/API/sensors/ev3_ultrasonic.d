.objs/API/sensors/ev3_ultrasonic.o: API/sensors/ev3_ultrasonic.c \
  API/inputs/ev3_input_uart.h API/sensors/utility.h \
  API/sensors/ev3_sensors.h
API/inputs/ev3_input_uart.h:
API/sensors/utility.h:
API/sensors/ev3_sensors.h:
