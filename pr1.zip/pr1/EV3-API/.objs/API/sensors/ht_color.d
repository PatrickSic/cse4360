.objs/API/sensors/ht_color.o: API/sensors/ht_color.c \
  API/inputs/ev3_input_iic.h API/sensors/ev3_sensors.h
API/inputs/ev3_input_iic.h:
API/sensors/ev3_sensors.h:
