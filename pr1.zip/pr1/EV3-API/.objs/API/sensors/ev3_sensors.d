.objs/API/sensors/ev3_sensors.o: API/sensors/ev3_sensors.c \
  API/sensors/ev3_sensors.h
API/sensors/ev3_sensors.h:
