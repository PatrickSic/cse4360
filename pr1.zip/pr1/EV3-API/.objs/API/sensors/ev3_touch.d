.objs/API/sensors/ev3_touch.o: API/sensors/ev3_touch.c \
  API/inputs/ev3_input_analog.h API/sensors/ev3_sensors.h
API/inputs/ev3_input_analog.h:
API/sensors/ev3_sensors.h:
