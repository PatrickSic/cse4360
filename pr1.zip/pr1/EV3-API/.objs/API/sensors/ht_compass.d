.objs/API/sensors/ht_compass.o: API/sensors/ht_compass.c \
  API/inputs/ev3_input_iic.h API/sensors/ev3_sensors.h
API/inputs/ev3_input_iic.h:
API/sensors/ev3_sensors.h:
