.objs/API/sensors/ev3_color.o: API/sensors/ev3_color.c \
  API/inputs/ev3_input_uart.h API/sensors/utility.h \
  API/sensors/ev3_sensors.h
API/inputs/ev3_input_uart.h:
API/sensors/utility.h:
API/sensors/ev3_sensors.h:
