.objs/API/sensors/nxt_temperature.o: API/sensors/nxt_temperature.c \
  API/inputs/ev3_input_iic.h API/sensors/ev3_sensors.h
API/inputs/ev3_input_iic.h:
API/sensors/ev3_sensors.h:
