.objs/API/sensors/pixy_cam.o: API/sensors/pixy_cam.c \
  API/inputs/ev3_input_iic.h API/sensors/ev3_sensors.h
API/inputs/ev3_input_iic.h:
API/sensors/ev3_sensors.h:
