.objs/API/sensors/nxt_sound.o: API/sensors/nxt_sound.c \
  API/inputs/ev3_input_analog.h API/sensors/ev3_sensors.h
API/inputs/ev3_input_analog.h:
API/sensors/ev3_sensors.h:
