.objs/API/sensors/ev3_ir.o: API/sensors/ev3_ir.c \
  API/inputs/ev3_input_uart.h API/sensors/utility.h \
  API/sensors/ev3_sensors.h
API/inputs/ev3_input_uart.h:
API/sensors/utility.h:
API/sensors/ev3_sensors.h:
