.objs/API/sensors/c4ev3_compatibility.o: \
  API/sensors/c4ev3_compatibility.c API/sensors/ev3_sensors.h
API/sensors/ev3_sensors.h:
