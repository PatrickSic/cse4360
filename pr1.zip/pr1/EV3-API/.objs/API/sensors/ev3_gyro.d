.objs/API/sensors/ev3_gyro.o: API/sensors/ev3_gyro.c \
  API/inputs/ev3_input_uart.h API/sensors/ev3_sensors.h \
  API/sensors/utility.h
API/inputs/ev3_input_uart.h:
API/sensors/ev3_sensors.h:
API/sensors/utility.h:
