.objs/API/ev3_timer.ts.o: API/ev3_timer.ts.c API/ev3_timer.private.h
API/ev3_timer.private.h:
