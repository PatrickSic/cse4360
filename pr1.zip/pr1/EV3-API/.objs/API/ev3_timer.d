.objs/API/ev3_timer.o: API/ev3_timer.c API/ev3_timer.private.h
API/ev3_timer.private.h:
