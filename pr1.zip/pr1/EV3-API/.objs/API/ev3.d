.objs/API/ev3.o: API/ev3.c API/inputs/ev3_input.h \
  API/sensors/ev3_sensors.h
API/inputs/ev3_input.h:
API/sensors/ev3_sensors.h:
