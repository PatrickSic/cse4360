.objs/API/inputs/ev3_input.o: API/inputs/ev3_input.c \
  API/inputs/ev3_input.h API/inputs/ev3_input_uart.h \
  API/inputs/ev3_input_analog.h API/inputs/ev3_input_iic.h
API/inputs/ev3_input.h:
API/inputs/ev3_input_uart.h:
API/inputs/ev3_input_analog.h:
API/inputs/ev3_input_iic.h:
