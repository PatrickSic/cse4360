.objs/API/inputs/ev3_input_iic.o: API/inputs/ev3_input_iic.c \
  API/inputs/ev3_input_iic.h API/inputs/ev3_input.h
API/inputs/ev3_input_iic.h:
API/inputs/ev3_input.h:
