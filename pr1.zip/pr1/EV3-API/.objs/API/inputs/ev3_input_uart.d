.objs/API/inputs/ev3_input_uart.o: API/inputs/ev3_input_uart.c \
  API/inputs/ev3_input_uart.h
API/inputs/ev3_input_uart.h:
