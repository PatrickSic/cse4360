.objs/API/inputs/ev3_input_analog.o: API/inputs/ev3_input_analog.c \
  API/inputs/ev3_input_analog.h
API/inputs/ev3_input_analog.h:
