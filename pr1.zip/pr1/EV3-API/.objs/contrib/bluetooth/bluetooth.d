.objs/contrib/bluetooth/bluetooth.o: contrib/bluetooth/bluetooth.c \
  contrib/bluetooth/bluetooth.h contrib/bluetooth/hci.h
contrib/bluetooth/bluetooth.h:
contrib/bluetooth/hci.h:
